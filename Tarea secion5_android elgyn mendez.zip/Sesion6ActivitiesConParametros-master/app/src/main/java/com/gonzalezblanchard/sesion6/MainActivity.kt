package com.gonzalezblanchard.sesion6

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startActivity
import com.gonzalezblanchard.sesion6.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    fun cambiarPantalla(view: View) {
        val intent = Intent(this, DetailPokemonActivity::class.java).apply {
            putExtra("TITULO", "Proyecto X")
            putExtra("DESCRIPCION", "Tres estudiantes de secundaria deciden organizar una fiesta salvaje en casa de uno de ellos, aprovechando que sus padres no están. Quieren hacer que la fiesta sea inolvidable, así que deciden grabarlo todo. Parece que la fiesta es todo un éxito: todo el mundo está bebiendo y los ánimos están por los aires. Sin embargo, una serie de complicaciones imprevistas harán que la fiesta se descontrole.")
            putExtra("FOTO", "https://www.lavanguardia.com/peliculas-series/images/movie/poster/2012/3/w1280/owF9NIcQOPFAOjp2pni8BsVlnRq.jpg")
        }
        startActivity(intent)
    }

    fun cambiarPantallaCharizard(view: View) {
        val intent = Intent(this, DetailPokemonActivity::class.java).apply {
            putExtra("TITULO", "shrek")
            putExtra(
                "DESCRIPCION",
                "Shrek es una película de comedia estadounidense de animación por computadora estrenada en 2001 basada en el libro homónimo de William Steig de 1990. Es la primera entrega de la franquicia Shrek."
            )
            putExtra("FOTO", "https://e7.pngegg.com/pngimages/243/742/png-clipart-shrek-shrek.png")
        }
        startActivity(intent)
    }

    fun cambiarPantallaNovia(view: View) {
        val intent = Intent(this, DetailPokemonActivity::class.java).apply {
            putExtra("TITULO", "El cadaver de la novia")
            putExtra(
                "DESCRIPCION",
                "Ambientada en una aldea europea del siglo 19, esta película de animación cuenta la historia de Víctor (voz de Johnny Depp), un joven que es llevado repentinamente al inframundo al casarse accidentalmente con una misteriosa novia que es un cadáver (voz de Helena Bonham Carter) mientras que su novia real, Victoria (voz de Emily Watson), le espera en la tierra de los vivos. Aún cuando la vida en el mundo de los muertos resulta ser mucho más colorida de lo que su estricta educación ofrecía, Víctor comprende que no existe nada en esta vida ni en la otra, que lo pueda separar de su verdadero amor. Es una historia de optimismo, romanticismo y de auténtica vida después de la muerte, que es contada al clásico estilo Tim Burton."
            )
            putExtra("FOTO", "https://play-lh.googleusercontent.com/ypA2Aa3cldT--4D8Wnd7TSKtIJeCnkYQeOvnYvPAa3k7K72_wjGmlCnVOt0b1yanxpis")
        }
        startActivity(intent)
    }
    fun cambiarPantallaGato(view: View) {
        val intent = Intent(this, DetailPokemonActivity::class.java).apply {
            putExtra("TITULO", "El gato con botas")
            putExtra(
                "DESCRIPCION",
                "El Gato con Botas descubre que, debido a su pasión por la aventura, ha gastado ya 8 de sus 9 vidas. Por tanto, emprende un peligroso viaje en busca del legendario Último Deseo para solicitar que le restauren las vidas que ya perdió."
            )
            putExtra("FOTO", "https://static.wikia.nocookie.net/ficcion-sin-limites/images/f/f0/El_%C3%BAltimo_deseo.jpg/revision/latest?cb=20230127065601&path-prefix=es")
        }
        startActivity(intent)
    }
}

